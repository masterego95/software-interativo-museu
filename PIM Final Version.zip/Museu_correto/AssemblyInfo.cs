﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Runtime.CompilerServices;

[assembly: InternalsVisibleTo("TestePim.Tests")]
namespace Museu_Pim
{
    internal class AssemblyInfo
    {

    }
}
