﻿namespace Museu_Pim.Formularios
{
    partial class Feedback
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            chn_CapsLock = new CheckBox();
            Chn_Shift = new CheckBox();
            Btn_Tres = new Button();
            Btn_PontoDir = new Button();
            Btn_Seis = new Button();
            Btn_Soma = new Button();
            Btn_Nove = new Button();
            Btn_Menos = new Button();
            Btn_Multiplicar = new Button();
            Btn_Dois = new Button();
            Btn_Um = new Button();
            Btn_Zero = new Button();
            Btn_VirgulaDir = new Button();
            button53 = new Button();
            Btn_PontoVirgila = new Button();
            Btn_Ponto = new Button();
            Btn_Virgula = new Button();
            Btn_M = new Button();
            Btn_N = new Button();
            Btn_B = new Button();
            Btn_V = new Button();
            Btn_C = new Button();
            Btn_X = new Button();
            Btn_Z = new Button();
            Btn_Cinco = new Button();
            Btn_Quatro = new Button();
            Btn_Interogacao = new Button();
            Btn_ChapeueCobra = new Button();
            Btn_Ç = new Button();
            Btn_L = new Button();
            Btn_K = new Button();
            Btn_J = new Button();
            Btn_H = new Button();
            Btn_G = new Button();
            Btn_F = new Button();
            Btn_D = new Button();
            Btn_S = new Button();
            Btn_A = new Button();
            Btn_Oito = new Button();
            Btn_Sete = new Button();
            Btn_Backspage = new Button();
            Btn_AbreChaves = new Button();
            Btn_AssentoS = new Button();
            Btn_P = new Button();
            Btn_O = new Button();
            Btn_I = new Button();
            Btn_U = new Button();
            Btn_Y = new Button();
            Btn_T = new Button();
            Btn_R = new Button();
            Btn_E = new Button();
            Btn_W = new Button();
            Btn_Q = new Button();
            Btn_Dividir = new Button();
            Btn_FechsChaves = new Button();
            Btn_MaisIgual = new Button();
            btn_UnderlaineeMenos = new Button();
            btn_FechaParetenses = new Button();
            btn_AbriParetenses = new Button();
            btn_Asteristico = new Button();
            btn_Ecomercial = new Button();
            btn_doispontoscima = new Button();
            btn_Porcetagem = new Button();
            btn_sifrao = new Button();
            btn_hastag = new Button();
            btn_Arroba = new Button();
            btn_esclamacao = new Button();
            btn_Aspas = new Button();
            Lbl_Titulo = new Label();
            Txb_Feedback = new TextBox();
            label4 = new Label();
            txb_Sobrenome = new TextBox();
            label3 = new Label();
            lbl_Senha = new Label();
            lbl_Nome = new Label();
            txb_Idade = new TextBox();
            txb_Nome = new TextBox();
            Btn_EnviarFeedBack = new Modulos.DesinButtons();
            Btn_Home = new Modulos.DesinButtons();
            Btn_Formulario = new Modulos.DesinButtons();
            pictureBox1 = new PictureBox();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            SuspendLayout();
            // 
            // chn_CapsLock
            // 
            chn_CapsLock.AllowDrop = true;
            chn_CapsLock.Appearance = Appearance.Button;
            chn_CapsLock.BackColor = SystemColors.ActiveCaptionText;
            chn_CapsLock.FlatAppearance.BorderColor = Color.BlueViolet;
            chn_CapsLock.FlatStyle = FlatStyle.Flat;
            chn_CapsLock.ForeColor = Color.SlateBlue;
            chn_CapsLock.Location = new Point(32, 515);
            chn_CapsLock.Name = "chn_CapsLock";
            chn_CapsLock.Size = new Size(75, 50);
            chn_CapsLock.TabIndex = 222;
            chn_CapsLock.Text = "Caps Lock";
            chn_CapsLock.UseVisualStyleBackColor = false;
            chn_CapsLock.CheckedChanged += chn_CapsLock_CheckedChanged;
            // 
            // Chn_Shift
            // 
            Chn_Shift.AllowDrop = true;
            Chn_Shift.Appearance = Appearance.Button;
            Chn_Shift.BackColor = SystemColors.ActiveCaptionText;
            Chn_Shift.FlatAppearance.BorderColor = Color.BlueViolet;
            Chn_Shift.FlatStyle = FlatStyle.Flat;
            Chn_Shift.ForeColor = Color.SlateBlue;
            Chn_Shift.Location = new Point(32, 571);
            Chn_Shift.Name = "Chn_Shift";
            Chn_Shift.Size = new Size(75, 50);
            Chn_Shift.TabIndex = 221;
            Chn_Shift.Text = "Shift";
            Chn_Shift.UseVisualStyleBackColor = false;
            Chn_Shift.CheckedChanged += Chn_Shift_CheckedChanged;
            // 
            // Btn_Tres
            // 
            Btn_Tres.AllowDrop = true;
            Btn_Tres.BackColor = SystemColors.ActiveCaptionText;
            Btn_Tres.FlatAppearance.BorderColor = Color.BlueViolet;
            Btn_Tres.FlatStyle = FlatStyle.Flat;
            Btn_Tres.ForeColor = Color.SlateBlue;
            Btn_Tres.Location = new Point(1165, 571);
            Btn_Tres.Name = "Btn_Tres";
            Btn_Tres.Size = new Size(75, 50);
            Btn_Tres.TabIndex = 220;
            Btn_Tres.Text = "3";
            Btn_Tres.UseVisualStyleBackColor = false;
            Btn_Tres.Click += Btn_Tres_Click;
            // 
            // Btn_PontoDir
            // 
            Btn_PontoDir.AllowDrop = true;
            Btn_PontoDir.BackColor = SystemColors.ActiveCaptionText;
            Btn_PontoDir.FlatAppearance.BorderColor = Color.BlueViolet;
            Btn_PontoDir.FlatStyle = FlatStyle.Flat;
            Btn_PontoDir.ForeColor = Color.SlateBlue;
            Btn_PontoDir.Location = new Point(844, 627);
            Btn_PontoDir.Name = "Btn_PontoDir";
            Btn_PontoDir.Size = new Size(75, 50);
            Btn_PontoDir.TabIndex = 219;
            Btn_PontoDir.Text = ".";
            Btn_PontoDir.UseVisualStyleBackColor = false;
            Btn_PontoDir.Click += Btn_PontoDir_Click;
            // 
            // Btn_Seis
            // 
            Btn_Seis.AllowDrop = true;
            Btn_Seis.BackColor = SystemColors.ActiveCaptionText;
            Btn_Seis.FlatAppearance.BorderColor = Color.BlueViolet;
            Btn_Seis.FlatStyle = FlatStyle.Flat;
            Btn_Seis.ForeColor = Color.SlateBlue;
            Btn_Seis.Location = new Point(1165, 515);
            Btn_Seis.Name = "Btn_Seis";
            Btn_Seis.Size = new Size(75, 50);
            Btn_Seis.TabIndex = 218;
            Btn_Seis.Text = "6";
            Btn_Seis.UseVisualStyleBackColor = false;
            Btn_Seis.Click += Btn_Seis_Click;
            // 
            // Btn_Soma
            // 
            Btn_Soma.AllowDrop = true;
            Btn_Soma.BackColor = SystemColors.ActiveCaptionText;
            Btn_Soma.FlatAppearance.BorderColor = Color.BlueViolet;
            Btn_Soma.FlatStyle = FlatStyle.Flat;
            Btn_Soma.ForeColor = Color.SlateBlue;
            Btn_Soma.Location = new Point(925, 627);
            Btn_Soma.Name = "Btn_Soma";
            Btn_Soma.Size = new Size(75, 50);
            Btn_Soma.TabIndex = 217;
            Btn_Soma.Text = "+";
            Btn_Soma.UseVisualStyleBackColor = false;
            Btn_Soma.Click += Btn_Soma_Click;
            // 
            // Btn_Nove
            // 
            Btn_Nove.AllowDrop = true;
            Btn_Nove.BackColor = SystemColors.ActiveCaptionText;
            Btn_Nove.FlatAppearance.BorderColor = Color.BlueViolet;
            Btn_Nove.FlatStyle = FlatStyle.Flat;
            Btn_Nove.ForeColor = Color.SlateBlue;
            Btn_Nove.Location = new Point(1165, 459);
            Btn_Nove.Name = "Btn_Nove";
            Btn_Nove.Size = new Size(75, 50);
            Btn_Nove.TabIndex = 216;
            Btn_Nove.Text = "9";
            Btn_Nove.UseVisualStyleBackColor = false;
            Btn_Nove.Click += Btn_Nove_Click;
            // 
            // Btn_Menos
            // 
            Btn_Menos.AllowDrop = true;
            Btn_Menos.BackColor = SystemColors.ActiveCaptionText;
            Btn_Menos.FlatAppearance.BorderColor = Color.BlueViolet;
            Btn_Menos.FlatStyle = FlatStyle.Flat;
            Btn_Menos.ForeColor = Color.SlateBlue;
            Btn_Menos.Location = new Point(520, 627);
            Btn_Menos.Name = "Btn_Menos";
            Btn_Menos.Size = new Size(75, 50);
            Btn_Menos.TabIndex = 215;
            Btn_Menos.Text = "-";
            Btn_Menos.UseVisualStyleBackColor = false;
            Btn_Menos.Click += Btn_Menos_Click;
            // 
            // Btn_Multiplicar
            // 
            Btn_Multiplicar.AllowDrop = true;
            Btn_Multiplicar.BackColor = SystemColors.ActiveCaptionText;
            Btn_Multiplicar.FlatAppearance.BorderColor = Color.BlueViolet;
            Btn_Multiplicar.FlatStyle = FlatStyle.Flat;
            Btn_Multiplicar.ForeColor = Color.SlateBlue;
            Btn_Multiplicar.Location = new Point(763, 627);
            Btn_Multiplicar.Name = "Btn_Multiplicar";
            Btn_Multiplicar.Size = new Size(75, 50);
            Btn_Multiplicar.TabIndex = 214;
            Btn_Multiplicar.Text = "*";
            Btn_Multiplicar.UseVisualStyleBackColor = false;
            Btn_Multiplicar.Click += Btn_Multiplicar_Click;
            // 
            // Btn_Dois
            // 
            Btn_Dois.AllowDrop = true;
            Btn_Dois.BackColor = SystemColors.ActiveCaptionText;
            Btn_Dois.FlatAppearance.BorderColor = Color.BlueViolet;
            Btn_Dois.FlatStyle = FlatStyle.Flat;
            Btn_Dois.ForeColor = Color.SlateBlue;
            Btn_Dois.Location = new Point(1085, 571);
            Btn_Dois.Name = "Btn_Dois";
            Btn_Dois.Size = new Size(75, 50);
            Btn_Dois.TabIndex = 213;
            Btn_Dois.Text = "2";
            Btn_Dois.UseVisualStyleBackColor = false;
            Btn_Dois.Click += Btn_Dois_Click;
            // 
            // Btn_Um
            // 
            Btn_Um.AllowDrop = true;
            Btn_Um.BackColor = SystemColors.ActiveCaptionText;
            Btn_Um.FlatAppearance.BorderColor = Color.BlueViolet;
            Btn_Um.FlatStyle = FlatStyle.Flat;
            Btn_Um.ForeColor = Color.SlateBlue;
            Btn_Um.Location = new Point(1004, 571);
            Btn_Um.Name = "Btn_Um";
            Btn_Um.Size = new Size(75, 50);
            Btn_Um.TabIndex = 212;
            Btn_Um.Text = "1";
            Btn_Um.UseVisualStyleBackColor = false;
            Btn_Um.Click += Btn_Um_Click;
            // 
            // Btn_Zero
            // 
            Btn_Zero.AllowDrop = true;
            Btn_Zero.BackColor = SystemColors.ActiveCaptionText;
            Btn_Zero.FlatAppearance.BorderColor = Color.BlueViolet;
            Btn_Zero.FlatStyle = FlatStyle.Flat;
            Btn_Zero.ForeColor = Color.SlateBlue;
            Btn_Zero.Location = new Point(1004, 627);
            Btn_Zero.Name = "Btn_Zero";
            Btn_Zero.Size = new Size(155, 50);
            Btn_Zero.TabIndex = 211;
            Btn_Zero.Text = "0";
            Btn_Zero.UseVisualStyleBackColor = false;
            Btn_Zero.Click += Btn_Zero_Click;
            // 
            // Btn_VirgulaDir
            // 
            Btn_VirgulaDir.AllowDrop = true;
            Btn_VirgulaDir.BackColor = SystemColors.ActiveCaptionText;
            Btn_VirgulaDir.FlatAppearance.BorderColor = Color.BlueViolet;
            Btn_VirgulaDir.FlatStyle = FlatStyle.Flat;
            Btn_VirgulaDir.ForeColor = Color.SlateBlue;
            Btn_VirgulaDir.Location = new Point(1165, 627);
            Btn_VirgulaDir.Name = "Btn_VirgulaDir";
            Btn_VirgulaDir.Size = new Size(75, 50);
            Btn_VirgulaDir.TabIndex = 210;
            Btn_VirgulaDir.Text = ",";
            Btn_VirgulaDir.UseVisualStyleBackColor = false;
            Btn_VirgulaDir.Click += Btn_VirgulaDir_Click;
            // 
            // button53
            // 
            button53.AllowDrop = true;
            button53.BackColor = SystemColors.ActiveCaptionText;
            button53.FlatAppearance.BorderColor = Color.BlueViolet;
            button53.FlatStyle = FlatStyle.Flat;
            button53.ForeColor = Color.SlateBlue;
            button53.Location = new Point(32, 627);
            button53.Name = "button53";
            button53.Size = new Size(482, 50);
            button53.TabIndex = 209;
            button53.Text = "Space";
            button53.UseVisualStyleBackColor = false;
            button53.Click += button53_Click;
            // 
            // Btn_PontoVirgila
            // 
            Btn_PontoVirgila.AllowDrop = true;
            Btn_PontoVirgila.BackColor = SystemColors.ActiveCaptionText;
            Btn_PontoVirgila.FlatAppearance.BorderColor = Color.BlueViolet;
            Btn_PontoVirgila.FlatStyle = FlatStyle.Flat;
            Btn_PontoVirgila.ForeColor = Color.SlateBlue;
            Btn_PontoVirgila.Location = new Point(923, 459);
            Btn_PontoVirgila.Name = "Btn_PontoVirgila";
            Btn_PontoVirgila.Size = new Size(75, 50);
            Btn_PontoVirgila.TabIndex = 208;
            Btn_PontoVirgila.Text = ":\r\n;";
            Btn_PontoVirgila.UseVisualStyleBackColor = false;
            Btn_PontoVirgila.Click += Btn_PontoVirgila_Click;
            // 
            // Btn_Ponto
            // 
            Btn_Ponto.AllowDrop = true;
            Btn_Ponto.BackColor = SystemColors.ActiveCaptionText;
            Btn_Ponto.FlatAppearance.BorderColor = Color.BlueViolet;
            Btn_Ponto.FlatStyle = FlatStyle.Flat;
            Btn_Ponto.ForeColor = Color.SlateBlue;
            Btn_Ponto.Location = new Point(842, 459);
            Btn_Ponto.Name = "Btn_Ponto";
            Btn_Ponto.Size = new Size(75, 50);
            Btn_Ponto.TabIndex = 207;
            Btn_Ponto.Text = ">\r\n.";
            Btn_Ponto.UseVisualStyleBackColor = false;
            Btn_Ponto.Click += Btn_Ponto_Click;
            // 
            // Btn_Virgula
            // 
            Btn_Virgula.AllowDrop = true;
            Btn_Virgula.BackColor = SystemColors.ActiveCaptionText;
            Btn_Virgula.FlatAppearance.BorderColor = Color.BlueViolet;
            Btn_Virgula.FlatStyle = FlatStyle.Flat;
            Btn_Virgula.ForeColor = Color.SlateBlue;
            Btn_Virgula.Location = new Point(842, 515);
            Btn_Virgula.Name = "Btn_Virgula";
            Btn_Virgula.Size = new Size(75, 50);
            Btn_Virgula.TabIndex = 206;
            Btn_Virgula.Text = "<\r\n,";
            Btn_Virgula.UseVisualStyleBackColor = false;
            Btn_Virgula.Click += Btn_Virgula_Click;
            // 
            // Btn_M
            // 
            Btn_M.AllowDrop = true;
            Btn_M.BackColor = SystemColors.ActiveCaptionText;
            Btn_M.FlatAppearance.BorderColor = Color.BlueViolet;
            Btn_M.FlatStyle = FlatStyle.Flat;
            Btn_M.ForeColor = Color.SlateBlue;
            Btn_M.Location = new Point(599, 571);
            Btn_M.Name = "Btn_M";
            Btn_M.Size = new Size(75, 50);
            Btn_M.TabIndex = 205;
            Btn_M.Text = "M";
            Btn_M.UseVisualStyleBackColor = false;
            Btn_M.Click += Btn_M_Click;
            // 
            // Btn_N
            // 
            Btn_N.AllowDrop = true;
            Btn_N.BackColor = SystemColors.ActiveCaptionText;
            Btn_N.FlatAppearance.BorderColor = Color.BlueViolet;
            Btn_N.FlatStyle = FlatStyle.Flat;
            Btn_N.ForeColor = Color.SlateBlue;
            Btn_N.Location = new Point(518, 571);
            Btn_N.Name = "Btn_N";
            Btn_N.Size = new Size(75, 50);
            Btn_N.TabIndex = 204;
            Btn_N.Text = "N";
            Btn_N.UseVisualStyleBackColor = false;
            Btn_N.Click += Btn_N_Click;
            // 
            // Btn_B
            // 
            Btn_B.AllowDrop = true;
            Btn_B.BackColor = SystemColors.ActiveCaptionText;
            Btn_B.FlatAppearance.BorderColor = Color.BlueViolet;
            Btn_B.FlatStyle = FlatStyle.Flat;
            Btn_B.ForeColor = Color.SlateBlue;
            Btn_B.Location = new Point(437, 571);
            Btn_B.Name = "Btn_B";
            Btn_B.Size = new Size(75, 50);
            Btn_B.TabIndex = 203;
            Btn_B.Text = "B";
            Btn_B.UseVisualStyleBackColor = false;
            Btn_B.Click += Btn_B_Click;
            // 
            // Btn_V
            // 
            Btn_V.AllowDrop = true;
            Btn_V.BackColor = SystemColors.ActiveCaptionText;
            Btn_V.FlatAppearance.BorderColor = Color.BlueViolet;
            Btn_V.FlatStyle = FlatStyle.Flat;
            Btn_V.ForeColor = Color.SlateBlue;
            Btn_V.Location = new Point(356, 571);
            Btn_V.Name = "Btn_V";
            Btn_V.Size = new Size(75, 50);
            Btn_V.TabIndex = 202;
            Btn_V.Text = "V";
            Btn_V.UseVisualStyleBackColor = false;
            Btn_V.Click += Btn_V_Click;
            // 
            // Btn_C
            // 
            Btn_C.AllowDrop = true;
            Btn_C.BackColor = SystemColors.ActiveCaptionText;
            Btn_C.FlatAppearance.BorderColor = Color.BlueViolet;
            Btn_C.FlatStyle = FlatStyle.Flat;
            Btn_C.ForeColor = Color.SlateBlue;
            Btn_C.Location = new Point(275, 571);
            Btn_C.Name = "Btn_C";
            Btn_C.Size = new Size(75, 50);
            Btn_C.TabIndex = 201;
            Btn_C.Text = "C";
            Btn_C.UseVisualStyleBackColor = false;
            Btn_C.Click += Btn_C_Click;
            // 
            // Btn_X
            // 
            Btn_X.AllowDrop = true;
            Btn_X.BackColor = SystemColors.ActiveCaptionText;
            Btn_X.FlatAppearance.BorderColor = Color.BlueViolet;
            Btn_X.FlatStyle = FlatStyle.Flat;
            Btn_X.ForeColor = Color.SlateBlue;
            Btn_X.Location = new Point(194, 571);
            Btn_X.Name = "Btn_X";
            Btn_X.Size = new Size(75, 50);
            Btn_X.TabIndex = 200;
            Btn_X.Text = "X";
            Btn_X.UseVisualStyleBackColor = false;
            Btn_X.Click += Btn_X_Click;
            // 
            // Btn_Z
            // 
            Btn_Z.AllowDrop = true;
            Btn_Z.BackColor = SystemColors.ActiveCaptionText;
            Btn_Z.FlatAppearance.BorderColor = Color.BlueViolet;
            Btn_Z.FlatStyle = FlatStyle.Flat;
            Btn_Z.ForeColor = Color.SlateBlue;
            Btn_Z.Location = new Point(113, 571);
            Btn_Z.Name = "Btn_Z";
            Btn_Z.Size = new Size(75, 50);
            Btn_Z.TabIndex = 199;
            Btn_Z.Text = "Z";
            Btn_Z.UseVisualStyleBackColor = false;
            Btn_Z.Click += Btn_Z_Click;
            // 
            // Btn_Cinco
            // 
            Btn_Cinco.AllowDrop = true;
            Btn_Cinco.BackColor = SystemColors.ActiveCaptionText;
            Btn_Cinco.FlatAppearance.BorderColor = Color.BlueViolet;
            Btn_Cinco.FlatStyle = FlatStyle.Flat;
            Btn_Cinco.ForeColor = Color.SlateBlue;
            Btn_Cinco.Location = new Point(1085, 515);
            Btn_Cinco.Name = "Btn_Cinco";
            Btn_Cinco.Size = new Size(75, 50);
            Btn_Cinco.TabIndex = 198;
            Btn_Cinco.Text = "5";
            Btn_Cinco.UseVisualStyleBackColor = false;
            Btn_Cinco.Click += Btn_Cinco_Click;
            // 
            // Btn_Quatro
            // 
            Btn_Quatro.AllowDrop = true;
            Btn_Quatro.BackColor = SystemColors.ActiveCaptionText;
            Btn_Quatro.FlatAppearance.BorderColor = Color.BlueViolet;
            Btn_Quatro.FlatStyle = FlatStyle.Flat;
            Btn_Quatro.ForeColor = Color.SlateBlue;
            Btn_Quatro.Location = new Point(1004, 515);
            Btn_Quatro.Name = "Btn_Quatro";
            Btn_Quatro.Size = new Size(75, 50);
            Btn_Quatro.TabIndex = 197;
            Btn_Quatro.Text = "4";
            Btn_Quatro.UseVisualStyleBackColor = false;
            Btn_Quatro.Click += Btn_Quatro_Click;
            // 
            // Btn_Interogacao
            // 
            Btn_Interogacao.AllowDrop = true;
            Btn_Interogacao.BackColor = SystemColors.ActiveCaptionText;
            Btn_Interogacao.FlatAppearance.BorderColor = Color.BlueViolet;
            Btn_Interogacao.FlatStyle = FlatStyle.Flat;
            Btn_Interogacao.ForeColor = Color.SlateBlue;
            Btn_Interogacao.Location = new Point(761, 571);
            Btn_Interogacao.Name = "Btn_Interogacao";
            Btn_Interogacao.Size = new Size(75, 50);
            Btn_Interogacao.TabIndex = 196;
            Btn_Interogacao.Text = "?\r\n/";
            Btn_Interogacao.UseVisualStyleBackColor = false;
            Btn_Interogacao.Click += Btn_Interogacao_Click;
            // 
            // Btn_ChapeueCobra
            // 
            Btn_ChapeueCobra.AllowDrop = true;
            Btn_ChapeueCobra.BackColor = SystemColors.ActiveCaptionText;
            Btn_ChapeueCobra.FlatAppearance.BorderColor = Color.BlueViolet;
            Btn_ChapeueCobra.FlatStyle = FlatStyle.Flat;
            Btn_ChapeueCobra.ForeColor = Color.SlateBlue;
            Btn_ChapeueCobra.Location = new Point(842, 571);
            Btn_ChapeueCobra.Name = "Btn_ChapeueCobra";
            Btn_ChapeueCobra.Size = new Size(75, 50);
            Btn_ChapeueCobra.TabIndex = 195;
            Btn_ChapeueCobra.Text = "^\r\n~\r\n";
            Btn_ChapeueCobra.UseVisualStyleBackColor = false;
            Btn_ChapeueCobra.Click += Btn_ChapeueCobra_Click;
            // 
            // Btn_Ç
            // 
            Btn_Ç.AllowDrop = true;
            Btn_Ç.BackColor = SystemColors.ActiveCaptionText;
            Btn_Ç.FlatAppearance.BorderColor = Color.BlueViolet;
            Btn_Ç.FlatStyle = FlatStyle.Flat;
            Btn_Ç.ForeColor = Color.SlateBlue;
            Btn_Ç.Location = new Point(680, 571);
            Btn_Ç.Name = "Btn_Ç";
            Btn_Ç.Size = new Size(75, 50);
            Btn_Ç.TabIndex = 194;
            Btn_Ç.Text = "Ç";
            Btn_Ç.UseVisualStyleBackColor = false;
            Btn_Ç.Click += Btn_Ç_Click;
            // 
            // Btn_L
            // 
            Btn_L.AllowDrop = true;
            Btn_L.BackColor = SystemColors.ActiveCaptionText;
            Btn_L.FlatAppearance.BorderColor = Color.BlueViolet;
            Btn_L.FlatStyle = FlatStyle.Flat;
            Btn_L.ForeColor = Color.SlateBlue;
            Btn_L.Location = new Point(761, 515);
            Btn_L.Name = "Btn_L";
            Btn_L.Size = new Size(75, 50);
            Btn_L.TabIndex = 193;
            Btn_L.Text = "L";
            Btn_L.UseVisualStyleBackColor = false;
            Btn_L.Click += Btn_L_Click;
            // 
            // Btn_K
            // 
            Btn_K.AllowDrop = true;
            Btn_K.BackColor = SystemColors.ActiveCaptionText;
            Btn_K.FlatAppearance.BorderColor = Color.BlueViolet;
            Btn_K.FlatStyle = FlatStyle.Flat;
            Btn_K.ForeColor = Color.SlateBlue;
            Btn_K.Location = new Point(680, 515);
            Btn_K.Name = "Btn_K";
            Btn_K.Size = new Size(75, 50);
            Btn_K.TabIndex = 192;
            Btn_K.Text = "K";
            Btn_K.UseVisualStyleBackColor = false;
            Btn_K.Click += Btn_K_Click;
            // 
            // Btn_J
            // 
            Btn_J.AllowDrop = true;
            Btn_J.BackColor = SystemColors.ActiveCaptionText;
            Btn_J.FlatAppearance.BorderColor = Color.BlueViolet;
            Btn_J.FlatStyle = FlatStyle.Flat;
            Btn_J.ForeColor = Color.SlateBlue;
            Btn_J.Location = new Point(599, 515);
            Btn_J.Name = "Btn_J";
            Btn_J.Size = new Size(75, 50);
            Btn_J.TabIndex = 191;
            Btn_J.Text = "J";
            Btn_J.UseVisualStyleBackColor = false;
            Btn_J.Click += Btn_J_Click;
            // 
            // Btn_H
            // 
            Btn_H.AllowDrop = true;
            Btn_H.BackColor = SystemColors.ActiveCaptionText;
            Btn_H.FlatAppearance.BorderColor = Color.BlueViolet;
            Btn_H.FlatStyle = FlatStyle.Flat;
            Btn_H.ForeColor = Color.SlateBlue;
            Btn_H.Location = new Point(518, 515);
            Btn_H.Name = "Btn_H";
            Btn_H.Size = new Size(75, 50);
            Btn_H.TabIndex = 190;
            Btn_H.Text = "H";
            Btn_H.UseVisualStyleBackColor = false;
            Btn_H.Click += Btn_H_Click;
            // 
            // Btn_G
            // 
            Btn_G.AllowDrop = true;
            Btn_G.BackColor = SystemColors.ActiveCaptionText;
            Btn_G.FlatAppearance.BorderColor = Color.BlueViolet;
            Btn_G.FlatStyle = FlatStyle.Flat;
            Btn_G.ForeColor = Color.SlateBlue;
            Btn_G.Location = new Point(437, 515);
            Btn_G.Name = "Btn_G";
            Btn_G.Size = new Size(75, 50);
            Btn_G.TabIndex = 189;
            Btn_G.Text = "G";
            Btn_G.UseVisualStyleBackColor = false;
            Btn_G.Click += Btn_G_Click;
            // 
            // Btn_F
            // 
            Btn_F.AllowDrop = true;
            Btn_F.BackColor = SystemColors.ActiveCaptionText;
            Btn_F.FlatAppearance.BorderColor = Color.BlueViolet;
            Btn_F.FlatStyle = FlatStyle.Flat;
            Btn_F.ForeColor = Color.SlateBlue;
            Btn_F.Location = new Point(356, 515);
            Btn_F.Name = "Btn_F";
            Btn_F.Size = new Size(75, 50);
            Btn_F.TabIndex = 188;
            Btn_F.Text = "F";
            Btn_F.UseVisualStyleBackColor = false;
            Btn_F.Click += Btn_F_Click;
            // 
            // Btn_D
            // 
            Btn_D.AllowDrop = true;
            Btn_D.BackColor = SystemColors.ActiveCaptionText;
            Btn_D.FlatAppearance.BorderColor = Color.BlueViolet;
            Btn_D.FlatStyle = FlatStyle.Flat;
            Btn_D.ForeColor = Color.SlateBlue;
            Btn_D.Location = new Point(275, 515);
            Btn_D.Name = "Btn_D";
            Btn_D.Size = new Size(75, 50);
            Btn_D.TabIndex = 187;
            Btn_D.Text = "D";
            Btn_D.UseVisualStyleBackColor = false;
            Btn_D.Click += Btn_D_Click;
            // 
            // Btn_S
            // 
            Btn_S.AllowDrop = true;
            Btn_S.BackColor = SystemColors.ActiveCaptionText;
            Btn_S.FlatAppearance.BorderColor = Color.BlueViolet;
            Btn_S.FlatStyle = FlatStyle.Flat;
            Btn_S.ForeColor = Color.SlateBlue;
            Btn_S.Location = new Point(194, 515);
            Btn_S.Name = "Btn_S";
            Btn_S.Size = new Size(75, 50);
            Btn_S.TabIndex = 186;
            Btn_S.Text = "S";
            Btn_S.UseVisualStyleBackColor = false;
            Btn_S.Click += Btn_S_Click;
            // 
            // Btn_A
            // 
            Btn_A.AllowDrop = true;
            Btn_A.BackColor = SystemColors.ActiveCaptionText;
            Btn_A.FlatAppearance.BorderColor = Color.BlueViolet;
            Btn_A.FlatStyle = FlatStyle.Flat;
            Btn_A.ForeColor = Color.SlateBlue;
            Btn_A.Location = new Point(113, 515);
            Btn_A.Name = "Btn_A";
            Btn_A.Size = new Size(75, 50);
            Btn_A.TabIndex = 185;
            Btn_A.Text = "A";
            Btn_A.UseVisualStyleBackColor = false;
            Btn_A.Click += Btn_A_Click;
            // 
            // Btn_Oito
            // 
            Btn_Oito.AllowDrop = true;
            Btn_Oito.BackColor = SystemColors.ActiveCaptionText;
            Btn_Oito.FlatAppearance.BorderColor = Color.BlueViolet;
            Btn_Oito.FlatStyle = FlatStyle.Flat;
            Btn_Oito.ForeColor = Color.SlateBlue;
            Btn_Oito.Location = new Point(1085, 459);
            Btn_Oito.Name = "Btn_Oito";
            Btn_Oito.Size = new Size(75, 50);
            Btn_Oito.TabIndex = 184;
            Btn_Oito.Text = "8";
            Btn_Oito.UseVisualStyleBackColor = false;
            Btn_Oito.Click += Btn_Oito_Click;
            // 
            // Btn_Sete
            // 
            Btn_Sete.AllowDrop = true;
            Btn_Sete.BackColor = SystemColors.ActiveCaptionText;
            Btn_Sete.FlatAppearance.BorderColor = Color.BlueViolet;
            Btn_Sete.FlatStyle = FlatStyle.Flat;
            Btn_Sete.ForeColor = Color.SlateBlue;
            Btn_Sete.Location = new Point(1004, 459);
            Btn_Sete.Name = "Btn_Sete";
            Btn_Sete.Size = new Size(75, 50);
            Btn_Sete.TabIndex = 183;
            Btn_Sete.Text = "7";
            Btn_Sete.UseVisualStyleBackColor = false;
            Btn_Sete.Click += Btn_Sete_Click;
            // 
            // Btn_Backspage
            // 
            Btn_Backspage.AllowDrop = true;
            Btn_Backspage.BackColor = SystemColors.ActiveCaptionText;
            Btn_Backspage.FlatAppearance.BorderColor = Color.BlueViolet;
            Btn_Backspage.FlatStyle = FlatStyle.Flat;
            Btn_Backspage.ForeColor = Color.SlateBlue;
            Btn_Backspage.Location = new Point(761, 403);
            Btn_Backspage.Name = "Btn_Backspage";
            Btn_Backspage.Size = new Size(156, 50);
            Btn_Backspage.TabIndex = 182;
            Btn_Backspage.Text = "Backspace";
            Btn_Backspage.UseVisualStyleBackColor = false;
            Btn_Backspage.Click += Btn_Backspage_Click;
            // 
            // Btn_AbreChaves
            // 
            Btn_AbreChaves.AllowDrop = true;
            Btn_AbreChaves.BackColor = SystemColors.ActiveCaptionText;
            Btn_AbreChaves.FlatAppearance.BorderColor = Color.BlueViolet;
            Btn_AbreChaves.FlatStyle = FlatStyle.Flat;
            Btn_AbreChaves.ForeColor = Color.SlateBlue;
            Btn_AbreChaves.Location = new Point(1084, 403);
            Btn_AbreChaves.Name = "Btn_AbreChaves";
            Btn_AbreChaves.Size = new Size(75, 50);
            Btn_AbreChaves.TabIndex = 181;
            Btn_AbreChaves.Text = "{\r\n[\r\n";
            Btn_AbreChaves.UseVisualStyleBackColor = false;
            Btn_AbreChaves.Click += Btn_AbreChaves_Click;
            // 
            // Btn_AssentoS
            // 
            Btn_AssentoS.AllowDrop = true;
            Btn_AssentoS.BackColor = SystemColors.ActiveCaptionText;
            Btn_AssentoS.FlatAppearance.BorderColor = Color.BlueViolet;
            Btn_AssentoS.FlatStyle = FlatStyle.Flat;
            Btn_AssentoS.ForeColor = Color.SlateBlue;
            Btn_AssentoS.Location = new Point(1004, 403);
            Btn_AssentoS.Name = "Btn_AssentoS";
            Btn_AssentoS.Size = new Size(75, 50);
            Btn_AssentoS.TabIndex = 180;
            Btn_AssentoS.Text = "`\r\n´\r\n";
            Btn_AssentoS.UseVisualStyleBackColor = false;
            Btn_AssentoS.Click += Btn_AssentoS_Click;
            // 
            // Btn_P
            // 
            Btn_P.AllowDrop = true;
            Btn_P.BackColor = SystemColors.ActiveCaptionText;
            Btn_P.FlatAppearance.BorderColor = Color.BlueViolet;
            Btn_P.FlatStyle = FlatStyle.Flat;
            Btn_P.ForeColor = Color.SlateBlue;
            Btn_P.Location = new Point(761, 459);
            Btn_P.Name = "Btn_P";
            Btn_P.Size = new Size(75, 50);
            Btn_P.TabIndex = 179;
            Btn_P.Text = "P";
            Btn_P.UseVisualStyleBackColor = false;
            Btn_P.Click += Btn_P_Click;
            // 
            // Btn_O
            // 
            Btn_O.AllowDrop = true;
            Btn_O.BackColor = SystemColors.ActiveCaptionText;
            Btn_O.FlatAppearance.BorderColor = Color.BlueViolet;
            Btn_O.FlatStyle = FlatStyle.Flat;
            Btn_O.ForeColor = Color.SlateBlue;
            Btn_O.Location = new Point(680, 459);
            Btn_O.Name = "Btn_O";
            Btn_O.Size = new Size(75, 50);
            Btn_O.TabIndex = 178;
            Btn_O.Text = "O";
            Btn_O.UseVisualStyleBackColor = false;
            Btn_O.Click += Btn_O_Click;
            // 
            // Btn_I
            // 
            Btn_I.AllowDrop = true;
            Btn_I.BackColor = SystemColors.ActiveCaptionText;
            Btn_I.FlatAppearance.BorderColor = Color.BlueViolet;
            Btn_I.FlatStyle = FlatStyle.Flat;
            Btn_I.ForeColor = Color.SlateBlue;
            Btn_I.Location = new Point(599, 459);
            Btn_I.Name = "Btn_I";
            Btn_I.Size = new Size(75, 50);
            Btn_I.TabIndex = 177;
            Btn_I.Text = "I";
            Btn_I.UseVisualStyleBackColor = false;
            Btn_I.Click += Btn_I_Click;
            // 
            // Btn_U
            // 
            Btn_U.AllowDrop = true;
            Btn_U.BackColor = SystemColors.ActiveCaptionText;
            Btn_U.FlatAppearance.BorderColor = Color.BlueViolet;
            Btn_U.FlatStyle = FlatStyle.Flat;
            Btn_U.ForeColor = Color.SlateBlue;
            Btn_U.Location = new Point(518, 459);
            Btn_U.Name = "Btn_U";
            Btn_U.Size = new Size(75, 50);
            Btn_U.TabIndex = 176;
            Btn_U.Text = "U";
            Btn_U.UseVisualStyleBackColor = false;
            Btn_U.Click += Btn_U_Click;
            // 
            // Btn_Y
            // 
            Btn_Y.AllowDrop = true;
            Btn_Y.BackColor = SystemColors.ActiveCaptionText;
            Btn_Y.FlatAppearance.BorderColor = Color.BlueViolet;
            Btn_Y.FlatStyle = FlatStyle.Flat;
            Btn_Y.ForeColor = Color.SlateBlue;
            Btn_Y.Location = new Point(437, 459);
            Btn_Y.Name = "Btn_Y";
            Btn_Y.Size = new Size(75, 50);
            Btn_Y.TabIndex = 175;
            Btn_Y.Text = "Y";
            Btn_Y.UseVisualStyleBackColor = false;
            Btn_Y.Click += Btn_Y_Click;
            // 
            // Btn_T
            // 
            Btn_T.AllowDrop = true;
            Btn_T.BackColor = SystemColors.ActiveCaptionText;
            Btn_T.FlatAppearance.BorderColor = Color.BlueViolet;
            Btn_T.FlatStyle = FlatStyle.Flat;
            Btn_T.ForeColor = Color.SlateBlue;
            Btn_T.Location = new Point(356, 459);
            Btn_T.Name = "Btn_T";
            Btn_T.Size = new Size(75, 50);
            Btn_T.TabIndex = 174;
            Btn_T.Text = "T";
            Btn_T.UseVisualStyleBackColor = false;
            Btn_T.Click += Btn_T_Click;
            // 
            // Btn_R
            // 
            Btn_R.AllowDrop = true;
            Btn_R.BackColor = SystemColors.ActiveCaptionText;
            Btn_R.FlatAppearance.BorderColor = Color.BlueViolet;
            Btn_R.FlatStyle = FlatStyle.Flat;
            Btn_R.ForeColor = Color.SlateBlue;
            Btn_R.Location = new Point(275, 459);
            Btn_R.Name = "Btn_R";
            Btn_R.Size = new Size(75, 50);
            Btn_R.TabIndex = 173;
            Btn_R.Text = "R";
            Btn_R.UseVisualStyleBackColor = false;
            Btn_R.Click += Btn_R_Click;
            // 
            // Btn_E
            // 
            Btn_E.AllowDrop = true;
            Btn_E.BackColor = SystemColors.ActiveCaptionText;
            Btn_E.FlatAppearance.BorderColor = Color.BlueViolet;
            Btn_E.FlatStyle = FlatStyle.Flat;
            Btn_E.ForeColor = Color.SlateBlue;
            Btn_E.Location = new Point(194, 459);
            Btn_E.Name = "Btn_E";
            Btn_E.Size = new Size(75, 50);
            Btn_E.TabIndex = 172;
            Btn_E.Text = "E";
            Btn_E.UseVisualStyleBackColor = false;
            Btn_E.Click += Btn_E_Click;
            // 
            // Btn_W
            // 
            Btn_W.AllowDrop = true;
            Btn_W.BackColor = SystemColors.ActiveCaptionText;
            Btn_W.FlatAppearance.BorderColor = Color.BlueViolet;
            Btn_W.FlatStyle = FlatStyle.Flat;
            Btn_W.ForeColor = Color.SlateBlue;
            Btn_W.Location = new Point(113, 459);
            Btn_W.Name = "Btn_W";
            Btn_W.Size = new Size(75, 50);
            Btn_W.TabIndex = 171;
            Btn_W.Text = "W";
            Btn_W.UseVisualStyleBackColor = false;
            Btn_W.Click += Btn_W_Click;
            // 
            // Btn_Q
            // 
            Btn_Q.AllowDrop = true;
            Btn_Q.BackColor = SystemColors.ActiveCaptionText;
            Btn_Q.FlatAppearance.BorderColor = Color.BlueViolet;
            Btn_Q.FlatStyle = FlatStyle.Flat;
            Btn_Q.ForeColor = Color.SlateBlue;
            Btn_Q.Location = new Point(32, 459);
            Btn_Q.Name = "Btn_Q";
            Btn_Q.Size = new Size(75, 50);
            Btn_Q.TabIndex = 170;
            Btn_Q.Text = "Q";
            Btn_Q.UseVisualStyleBackColor = false;
            Btn_Q.Click += Btn_Q_Click;
            // 
            // Btn_Dividir
            // 
            Btn_Dividir.AllowDrop = true;
            Btn_Dividir.BackColor = SystemColors.ActiveCaptionText;
            Btn_Dividir.FlatAppearance.BorderColor = Color.BlueViolet;
            Btn_Dividir.FlatStyle = FlatStyle.Flat;
            Btn_Dividir.ForeColor = Color.SlateBlue;
            Btn_Dividir.Location = new Point(1165, 403);
            Btn_Dividir.Name = "Btn_Dividir";
            Btn_Dividir.Size = new Size(75, 50);
            Btn_Dividir.TabIndex = 169;
            Btn_Dividir.Text = "/";
            Btn_Dividir.UseVisualStyleBackColor = false;
            Btn_Dividir.Click += Btn_Dividir_Click;
            // 
            // Btn_FechsChaves
            // 
            Btn_FechsChaves.AllowDrop = true;
            Btn_FechsChaves.BackColor = SystemColors.ActiveCaptionText;
            Btn_FechsChaves.FlatAppearance.BorderColor = Color.BlueViolet;
            Btn_FechsChaves.FlatStyle = FlatStyle.Flat;
            Btn_FechsChaves.ForeColor = Color.SlateBlue;
            Btn_FechsChaves.Location = new Point(923, 515);
            Btn_FechsChaves.Name = "Btn_FechsChaves";
            Btn_FechsChaves.Size = new Size(75, 50);
            Btn_FechsChaves.TabIndex = 168;
            Btn_FechsChaves.Text = "}\r\n]";
            Btn_FechsChaves.UseVisualStyleBackColor = false;
            Btn_FechsChaves.Click += Btn_FechsChaves_Click;
            // 
            // Btn_MaisIgual
            // 
            Btn_MaisIgual.AllowDrop = true;
            Btn_MaisIgual.BackColor = SystemColors.ActiveCaptionText;
            Btn_MaisIgual.FlatAppearance.BorderColor = Color.BlueViolet;
            Btn_MaisIgual.FlatStyle = FlatStyle.Flat;
            Btn_MaisIgual.ForeColor = Color.SlateBlue;
            Btn_MaisIgual.Location = new Point(923, 571);
            Btn_MaisIgual.Name = "Btn_MaisIgual";
            Btn_MaisIgual.Size = new Size(75, 50);
            Btn_MaisIgual.TabIndex = 167;
            Btn_MaisIgual.Text = "+\r\n=";
            Btn_MaisIgual.UseVisualStyleBackColor = false;
            Btn_MaisIgual.Click += Btn_MaisIgual_Click;
            // 
            // btn_UnderlaineeMenos
            // 
            btn_UnderlaineeMenos.AllowDrop = true;
            btn_UnderlaineeMenos.BackColor = SystemColors.ActiveCaptionText;
            btn_UnderlaineeMenos.FlatAppearance.BorderColor = Color.BlueViolet;
            btn_UnderlaineeMenos.FlatStyle = FlatStyle.Flat;
            btn_UnderlaineeMenos.ForeColor = Color.SlateBlue;
            btn_UnderlaineeMenos.Location = new Point(923, 403);
            btn_UnderlaineeMenos.Name = "btn_UnderlaineeMenos";
            btn_UnderlaineeMenos.Size = new Size(75, 50);
            btn_UnderlaineeMenos.TabIndex = 166;
            btn_UnderlaineeMenos.Text = "_\r\n-\r\n";
            btn_UnderlaineeMenos.UseVisualStyleBackColor = false;
            btn_UnderlaineeMenos.Click += btn_UnderlaineeMenos_Click;
            // 
            // btn_FechaParetenses
            // 
            btn_FechaParetenses.AllowDrop = true;
            btn_FechaParetenses.BackColor = SystemColors.ActiveCaptionText;
            btn_FechaParetenses.FlatAppearance.BorderColor = Color.BlueViolet;
            btn_FechaParetenses.FlatStyle = FlatStyle.Flat;
            btn_FechaParetenses.ForeColor = Color.SlateBlue;
            btn_FechaParetenses.Location = new Point(682, 627);
            btn_FechaParetenses.Name = "btn_FechaParetenses";
            btn_FechaParetenses.Size = new Size(75, 50);
            btn_FechaParetenses.TabIndex = 165;
            btn_FechaParetenses.Text = ")";
            btn_FechaParetenses.UseVisualStyleBackColor = false;
            btn_FechaParetenses.Click += btn_FechaParetenses_Click;
            // 
            // btn_AbriParetenses
            // 
            btn_AbriParetenses.AllowDrop = true;
            btn_AbriParetenses.BackColor = SystemColors.ActiveCaptionText;
            btn_AbriParetenses.FlatAppearance.BorderColor = Color.BlueViolet;
            btn_AbriParetenses.FlatStyle = FlatStyle.Flat;
            btn_AbriParetenses.ForeColor = Color.SlateBlue;
            btn_AbriParetenses.Location = new Point(601, 627);
            btn_AbriParetenses.Name = "btn_AbriParetenses";
            btn_AbriParetenses.Size = new Size(75, 50);
            btn_AbriParetenses.TabIndex = 164;
            btn_AbriParetenses.Text = "(";
            btn_AbriParetenses.UseVisualStyleBackColor = false;
            btn_AbriParetenses.Click += btn_AbriParetenses_Click;
            // 
            // btn_Asteristico
            // 
            btn_Asteristico.AllowDrop = true;
            btn_Asteristico.BackColor = SystemColors.ActiveCaptionText;
            btn_Asteristico.FlatAppearance.BorderColor = Color.BlueViolet;
            btn_Asteristico.FlatStyle = FlatStyle.Flat;
            btn_Asteristico.ForeColor = Color.SlateBlue;
            btn_Asteristico.Location = new Point(680, 403);
            btn_Asteristico.Name = "btn_Asteristico";
            btn_Asteristico.Size = new Size(75, 50);
            btn_Asteristico.TabIndex = 163;
            btn_Asteristico.Text = "*";
            btn_Asteristico.UseVisualStyleBackColor = false;
            btn_Asteristico.Click += btn_Asteristico_Click;
            // 
            // btn_Ecomercial
            // 
            btn_Ecomercial.AllowDrop = true;
            btn_Ecomercial.BackColor = SystemColors.ActiveCaptionText;
            btn_Ecomercial.FlatAppearance.BorderColor = Color.BlueViolet;
            btn_Ecomercial.FlatStyle = FlatStyle.Flat;
            btn_Ecomercial.ForeColor = Color.SlateBlue;
            btn_Ecomercial.Location = new Point(599, 403);
            btn_Ecomercial.Name = "btn_Ecomercial";
            btn_Ecomercial.Size = new Size(75, 50);
            btn_Ecomercial.TabIndex = 162;
            btn_Ecomercial.Text = "&&";
            btn_Ecomercial.UseVisualStyleBackColor = false;
            btn_Ecomercial.Click += btn_Ecomercial_Click;
            // 
            // btn_doispontoscima
            // 
            btn_doispontoscima.AllowDrop = true;
            btn_doispontoscima.BackColor = SystemColors.ActiveCaptionText;
            btn_doispontoscima.FlatAppearance.BorderColor = Color.BlueViolet;
            btn_doispontoscima.FlatStyle = FlatStyle.Flat;
            btn_doispontoscima.ForeColor = Color.SlateBlue;
            btn_doispontoscima.Location = new Point(518, 403);
            btn_doispontoscima.Name = "btn_doispontoscima";
            btn_doispontoscima.Size = new Size(75, 50);
            btn_doispontoscima.TabIndex = 161;
            btn_doispontoscima.Text = "¨";
            btn_doispontoscima.UseVisualStyleBackColor = false;
            btn_doispontoscima.Click += btn_doispontoscima_Click;
            // 
            // btn_Porcetagem
            // 
            btn_Porcetagem.AllowDrop = true;
            btn_Porcetagem.BackColor = SystemColors.ActiveCaptionText;
            btn_Porcetagem.FlatAppearance.BorderColor = Color.BlueViolet;
            btn_Porcetagem.FlatStyle = FlatStyle.Flat;
            btn_Porcetagem.ForeColor = Color.SlateBlue;
            btn_Porcetagem.Location = new Point(437, 403);
            btn_Porcetagem.Name = "btn_Porcetagem";
            btn_Porcetagem.Size = new Size(75, 50);
            btn_Porcetagem.TabIndex = 160;
            btn_Porcetagem.Text = "%";
            btn_Porcetagem.UseVisualStyleBackColor = false;
            btn_Porcetagem.Click += btn_Porcetagem_Click;
            // 
            // btn_sifrao
            // 
            btn_sifrao.AllowDrop = true;
            btn_sifrao.BackColor = SystemColors.ActiveCaptionText;
            btn_sifrao.FlatAppearance.BorderColor = Color.BlueViolet;
            btn_sifrao.FlatStyle = FlatStyle.Flat;
            btn_sifrao.ForeColor = Color.SlateBlue;
            btn_sifrao.Location = new Point(356, 403);
            btn_sifrao.Name = "btn_sifrao";
            btn_sifrao.Size = new Size(75, 50);
            btn_sifrao.TabIndex = 159;
            btn_sifrao.Text = "$";
            btn_sifrao.UseVisualStyleBackColor = false;
            btn_sifrao.Click += btn_sifrao_Click;
            // 
            // btn_hastag
            // 
            btn_hastag.AllowDrop = true;
            btn_hastag.BackColor = SystemColors.ActiveCaptionText;
            btn_hastag.FlatAppearance.BorderColor = Color.BlueViolet;
            btn_hastag.FlatStyle = FlatStyle.Flat;
            btn_hastag.ForeColor = Color.SlateBlue;
            btn_hastag.Location = new Point(275, 403);
            btn_hastag.Name = "btn_hastag";
            btn_hastag.Size = new Size(75, 50);
            btn_hastag.TabIndex = 158;
            btn_hastag.Text = "#";
            btn_hastag.UseVisualStyleBackColor = false;
            btn_hastag.Click += btn_hastag_Click;
            // 
            // btn_Arroba
            // 
            btn_Arroba.AllowDrop = true;
            btn_Arroba.BackColor = SystemColors.ActiveCaptionText;
            btn_Arroba.FlatAppearance.BorderColor = Color.BlueViolet;
            btn_Arroba.FlatStyle = FlatStyle.Flat;
            btn_Arroba.ForeColor = Color.SlateBlue;
            btn_Arroba.Location = new Point(194, 403);
            btn_Arroba.Name = "btn_Arroba";
            btn_Arroba.Size = new Size(75, 50);
            btn_Arroba.TabIndex = 157;
            btn_Arroba.Text = "@";
            btn_Arroba.UseVisualStyleBackColor = false;
            btn_Arroba.Click += btn_Arroba_Click;
            // 
            // btn_esclamacao
            // 
            btn_esclamacao.AllowDrop = true;
            btn_esclamacao.BackColor = SystemColors.ActiveCaptionText;
            btn_esclamacao.FlatAppearance.BorderColor = Color.BlueViolet;
            btn_esclamacao.FlatStyle = FlatStyle.Flat;
            btn_esclamacao.ForeColor = Color.SlateBlue;
            btn_esclamacao.Location = new Point(113, 403);
            btn_esclamacao.Name = "btn_esclamacao";
            btn_esclamacao.Size = new Size(75, 50);
            btn_esclamacao.TabIndex = 156;
            btn_esclamacao.Text = "!";
            btn_esclamacao.UseVisualStyleBackColor = false;
            btn_esclamacao.Click += btn_esclamacao_Click;
            // 
            // btn_Aspas
            // 
            btn_Aspas.AllowDrop = true;
            btn_Aspas.BackColor = SystemColors.ActiveCaptionText;
            btn_Aspas.FlatAppearance.BorderColor = Color.BlueViolet;
            btn_Aspas.FlatAppearance.BorderSize = 2;
            btn_Aspas.FlatAppearance.MouseDownBackColor = Color.FromArgb(64, 0, 64);
            btn_Aspas.FlatAppearance.MouseOverBackColor = Color.FromArgb(64, 0, 64);
            btn_Aspas.FlatStyle = FlatStyle.Flat;
            btn_Aspas.ForeColor = Color.SlateBlue;
            btn_Aspas.Location = new Point(32, 403);
            btn_Aspas.Name = "btn_Aspas";
            btn_Aspas.Size = new Size(75, 50);
            btn_Aspas.TabIndex = 155;
            btn_Aspas.Text = "\"\r\n'";
            btn_Aspas.UseVisualStyleBackColor = false;
            btn_Aspas.Click += btn_Aspas_Click;
            // 
            // Lbl_Titulo
            // 
            Lbl_Titulo.AllowDrop = true;
            Lbl_Titulo.AutoSize = true;
            Lbl_Titulo.Font = new Font("Arial Narrow", 27.75F, FontStyle.Bold, GraphicsUnit.Point, 0);
            Lbl_Titulo.ForeColor = Color.MediumPurple;
            Lbl_Titulo.Location = new Point(12, 9);
            Lbl_Titulo.Name = "Lbl_Titulo";
            Lbl_Titulo.Size = new Size(1270, 43);
            Lbl_Titulo.TabIndex = 223;
            Lbl_Titulo.Text = "Como foi sua experiencia com nosso museu deixe aqui seu feedback sobre sua visita ";
            // 
            // Txb_Feedback
            // 
            Txb_Feedback.AllowDrop = true;
            Txb_Feedback.BackColor = SystemColors.WindowText;
            Txb_Feedback.Font = new Font("Arial Narrow", 15.75F, FontStyle.Bold, GraphicsUnit.Point, 0);
            Txb_Feedback.ForeColor = SystemColors.ButtonFace;
            Txb_Feedback.Location = new Point(448, 108);
            Txb_Feedback.Multiline = true;
            Txb_Feedback.Name = "Txb_Feedback";
            Txb_Feedback.Size = new Size(459, 145);
            Txb_Feedback.TabIndex = 224;
            Txb_Feedback.Click += txb_Fedback_CLick;
            Txb_Feedback.TextChanged += Txb_Feedback_TextChanged;
            // 
            // label4
            // 
            label4.AllowDrop = true;
            label4.AutoSize = true;
            label4.BackColor = SystemColors.ActiveCaptionText;
            label4.Font = new Font("Arial Narrow", 15.75F, FontStyle.Bold);
            label4.ForeColor = Color.MediumPurple;
            label4.Location = new Point(32, 159);
            label4.Name = "label4";
            label4.Size = new Size(115, 25);
            label4.TabIndex = 235;
            label4.Text = "Sobrenome:";
            // 
            // txb_Sobrenome
            // 
            txb_Sobrenome.AllowDrop = true;
            txb_Sobrenome.BackColor = SystemColors.WindowText;
            txb_Sobrenome.Font = new Font("Arial Narrow", 15.75F, FontStyle.Bold);
            txb_Sobrenome.ForeColor = SystemColors.ButtonFace;
            txb_Sobrenome.Location = new Point(32, 187);
            txb_Sobrenome.Name = "txb_Sobrenome";
            txb_Sobrenome.Size = new Size(200, 32);
            txb_Sobrenome.TabIndex = 234;
            txb_Sobrenome.Click += Txb_sobrenome_Click;
            txb_Sobrenome.TextChanged += txb_Sobrenome_TextChanged;
            // 
            // label3
            // 
            label3.AllowDrop = true;
            label3.AutoSize = true;
            label3.Font = new Font("Arial Narrow", 15.75F, FontStyle.Bold);
            label3.ForeColor = Color.MediumPurple;
            label3.Location = new Point(310, 215);
            label3.Name = "label3";
            label3.Size = new Size(101, 25);
            label3.TabIndex = 233;
            label3.Text = "Feedback:";
            // 
            // lbl_Senha
            // 
            lbl_Senha.AllowDrop = true;
            lbl_Senha.AutoSize = true;
            lbl_Senha.Font = new Font("Arial Narrow", 15.75F, FontStyle.Bold);
            lbl_Senha.ForeColor = Color.MediumPurple;
            lbl_Senha.Location = new Point(32, 235);
            lbl_Senha.Name = "lbl_Senha";
            lbl_Senha.Size = new Size(65, 25);
            lbl_Senha.TabIndex = 231;
            lbl_Senha.Text = "Idade:";
            // 
            // lbl_Nome
            // 
            lbl_Nome.AllowDrop = true;
            lbl_Nome.AutoSize = true;
            lbl_Nome.BackColor = SystemColors.ActiveCaptionText;
            lbl_Nome.Font = new Font("Arial Narrow", 15.75F, FontStyle.Bold);
            lbl_Nome.ForeColor = Color.MediumPurple;
            lbl_Nome.Location = new Point(32, 83);
            lbl_Nome.Name = "lbl_Nome";
            lbl_Nome.Size = new Size(71, 25);
            lbl_Nome.TabIndex = 230;
            lbl_Nome.Text = "Nome: ";
            // 
            // txb_Idade
            // 
            txb_Idade.AllowDrop = true;
            txb_Idade.BackColor = SystemColors.WindowText;
            txb_Idade.Font = new Font("Arial Narrow", 15.75F, FontStyle.Bold, GraphicsUnit.Point, 0);
            txb_Idade.ForeColor = SystemColors.ButtonFace;
            txb_Idade.Location = new Point(35, 263);
            txb_Idade.Name = "txb_Idade";
            txb_Idade.Size = new Size(201, 32);
            txb_Idade.TabIndex = 229;
            txb_Idade.Click += Txb_Idade_click;
            txb_Idade.TextChanged += txb_Idade_TextChanged;
            // 
            // txb_Nome
            // 
            txb_Nome.AllowDrop = true;
            txb_Nome.BackColor = SystemColors.WindowText;
            txb_Nome.Font = new Font("Arial Narrow", 15.75F, FontStyle.Bold);
            txb_Nome.ForeColor = SystemColors.ButtonFace;
            txb_Nome.Location = new Point(35, 111);
            txb_Nome.Name = "txb_Nome";
            txb_Nome.Size = new Size(198, 32);
            txb_Nome.TabIndex = 228;
            txb_Nome.Click += Txb_Nome_click;
            txb_Nome.TextChanged += txb_Nome_TextChanged;
            // 
            // Btn_EnviarFeedBack
            // 
            Btn_EnviarFeedBack.BackColor = Color.MediumSlateBlue;
            Btn_EnviarFeedBack.FlatAppearance.BorderSize = 0;
            Btn_EnviarFeedBack.FlatStyle = FlatStyle.Flat;
            Btn_EnviarFeedBack.Font = new Font("Arial Narrow", 14.25F, FontStyle.Bold, GraphicsUnit.Point, 0);
            Btn_EnviarFeedBack.ForeColor = Color.White;
            Btn_EnviarFeedBack.Location = new Point(1070, 136);
            Btn_EnviarFeedBack.Name = "Btn_EnviarFeedBack";
            Btn_EnviarFeedBack.Size = new Size(170, 49);
            Btn_EnviarFeedBack.TabIndex = 236;
            Btn_EnviarFeedBack.Text = "Enviar Feedback";
            Btn_EnviarFeedBack.UseVisualStyleBackColor = false;
            Btn_EnviarFeedBack.Click += desinButtons1_Click;
            // 
            // Btn_Home
            // 
            Btn_Home.BackColor = Color.MediumSlateBlue;
            Btn_Home.FlatAppearance.BorderSize = 0;
            Btn_Home.FlatStyle = FlatStyle.Flat;
            Btn_Home.Font = new Font("Arial Narrow", 20.25F, FontStyle.Bold, GraphicsUnit.Point, 0);
            Btn_Home.ForeColor = Color.White;
            Btn_Home.Location = new Point(1069, 191);
            Btn_Home.Name = "Btn_Home";
            Btn_Home.Size = new Size(170, 49);
            Btn_Home.TabIndex = 237;
            Btn_Home.Text = "Home";
            Btn_Home.UseVisualStyleBackColor = false;
            Btn_Home.Click += Btn_Home_Click;
            // 
            // Btn_Formulario
            // 
            Btn_Formulario.BackColor = Color.MediumSlateBlue;
            Btn_Formulario.FlatAppearance.BorderSize = 0;
            Btn_Formulario.FlatStyle = FlatStyle.Flat;
            Btn_Formulario.Font = new Font("Arial Narrow", 20.25F, FontStyle.Bold, GraphicsUnit.Point, 0);
            Btn_Formulario.ForeColor = Color.White;
            Btn_Formulario.Location = new Point(1070, 246);
            Btn_Formulario.Name = "Btn_Formulario";
            Btn_Formulario.Size = new Size(169, 49);
            Btn_Formulario.TabIndex = 238;
            Btn_Formulario.Text = "Formulário";
            Btn_Formulario.UseVisualStyleBackColor = false;
            Btn_Formulario.Click += Btn_Formulario_Click;
            // 
            // pictureBox1
            // 
            pictureBox1.Image = Properties.Resources.Using_Red_Yellow_Green_Performance_Indicators_Examples_That_Are_SMART;
            pictureBox1.Location = new Point(265, 108);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(189, 88);
            pictureBox1.SizeMode = PictureBoxSizeMode.Zoom;
            pictureBox1.TabIndex = 239;
            pictureBox1.TabStop = false;
            // 
            // Feedback
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = SystemColors.ActiveCaptionText;
            ClientSize = new Size(1284, 711);
            ControlBox = false;
            Controls.Add(pictureBox1);
            Controls.Add(Btn_Formulario);
            Controls.Add(Btn_Home);
            Controls.Add(Btn_EnviarFeedBack);
            Controls.Add(label4);
            Controls.Add(txb_Sobrenome);
            Controls.Add(label3);
            Controls.Add(lbl_Senha);
            Controls.Add(lbl_Nome);
            Controls.Add(txb_Idade);
            Controls.Add(txb_Nome);
            Controls.Add(Txb_Feedback);
            Controls.Add(Lbl_Titulo);
            Controls.Add(chn_CapsLock);
            Controls.Add(Chn_Shift);
            Controls.Add(Btn_Tres);
            Controls.Add(Btn_PontoDir);
            Controls.Add(Btn_Seis);
            Controls.Add(Btn_Soma);
            Controls.Add(Btn_Nove);
            Controls.Add(Btn_Menos);
            Controls.Add(Btn_Multiplicar);
            Controls.Add(Btn_Dois);
            Controls.Add(Btn_Um);
            Controls.Add(Btn_Zero);
            Controls.Add(Btn_VirgulaDir);
            Controls.Add(button53);
            Controls.Add(Btn_PontoVirgila);
            Controls.Add(Btn_Ponto);
            Controls.Add(Btn_Virgula);
            Controls.Add(Btn_M);
            Controls.Add(Btn_N);
            Controls.Add(Btn_B);
            Controls.Add(Btn_V);
            Controls.Add(Btn_C);
            Controls.Add(Btn_X);
            Controls.Add(Btn_Z);
            Controls.Add(Btn_Cinco);
            Controls.Add(Btn_Quatro);
            Controls.Add(Btn_Interogacao);
            Controls.Add(Btn_ChapeueCobra);
            Controls.Add(Btn_Ç);
            Controls.Add(Btn_L);
            Controls.Add(Btn_K);
            Controls.Add(Btn_J);
            Controls.Add(Btn_H);
            Controls.Add(Btn_G);
            Controls.Add(Btn_F);
            Controls.Add(Btn_D);
            Controls.Add(Btn_S);
            Controls.Add(Btn_A);
            Controls.Add(Btn_Oito);
            Controls.Add(Btn_Sete);
            Controls.Add(Btn_Backspage);
            Controls.Add(Btn_AbreChaves);
            Controls.Add(Btn_AssentoS);
            Controls.Add(Btn_P);
            Controls.Add(Btn_O);
            Controls.Add(Btn_I);
            Controls.Add(Btn_U);
            Controls.Add(Btn_Y);
            Controls.Add(Btn_T);
            Controls.Add(Btn_R);
            Controls.Add(Btn_E);
            Controls.Add(Btn_W);
            Controls.Add(Btn_Q);
            Controls.Add(Btn_Dividir);
            Controls.Add(Btn_FechsChaves);
            Controls.Add(Btn_MaisIgual);
            Controls.Add(btn_UnderlaineeMenos);
            Controls.Add(btn_FechaParetenses);
            Controls.Add(btn_AbriParetenses);
            Controls.Add(btn_Asteristico);
            Controls.Add(btn_Ecomercial);
            Controls.Add(btn_doispontoscima);
            Controls.Add(btn_Porcetagem);
            Controls.Add(btn_sifrao);
            Controls.Add(btn_hastag);
            Controls.Add(btn_Arroba);
            Controls.Add(btn_esclamacao);
            Controls.Add(btn_Aspas);
            ForeColor = SystemColors.ButtonFace;
            FormBorderStyle = FormBorderStyle.None;
            Name = "Feedback";
            ShowIcon = false;
            StartPosition = FormStartPosition.CenterScreen;
            Text = "Feedback";
            WindowState = FormWindowState.Maximized;
            Load += Feedback_Load;
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private CheckBox chn_CapsLock;
        private CheckBox Chn_Shift;
        private Button Btn_Tres;
        private Button Btn_PontoDir;
        private Button Btn_Seis;
        private Button Btn_Soma;
        private Button Btn_Nove;
        private Button Btn_Menos;
        private Button Btn_Multiplicar;
        private Button Btn_Dois;
        private Button Btn_Um;
        private Button Btn_Zero;
        private Button Btn_VirgulaDir;
        private Button button53;
        private Button Btn_PontoVirgila;
        private Button Btn_Ponto;
        private Button Btn_Virgula;
        private Button Btn_M;
        private Button Btn_N;
        private Button Btn_B;
        private Button Btn_V;
        private Button Btn_C;
        private Button Btn_X;
        private Button Btn_Z;
        private Button Btn_Cinco;
        private Button Btn_Quatro;
        private Button Btn_Interogacao;
        private Button Btn_ChapeueCobra;
        private Button Btn_Ç;
        private Button Btn_L;
        private Button Btn_K;
        private Button Btn_J;
        private Button Btn_H;
        private Button Btn_G;
        private Button Btn_F;
        private Button Btn_D;
        private Button Btn_S;
        private Button Btn_A;
        private Button Btn_Oito;
        private Button Btn_Sete;
        private Button Btn_Backspage;
        private Button Btn_AbreChaves;
        private Button Btn_AssentoS;
        private Button Btn_P;
        private Button Btn_O;
        private Button Btn_I;
        private Button Btn_U;
        private Button Btn_Y;
        private Button Btn_T;
        private Button Btn_R;
        private Button Btn_E;
        private Button Btn_W;
        private Button Btn_Q;
        private Button Btn_Dividir;
        private Button Btn_FechsChaves;
        private Button Btn_MaisIgual;
        private Button btn_UnderlaineeMenos;
        private Button btn_FechaParetenses;
        private Button btn_AbriParetenses;
        private Button btn_Asteristico;
        private Button btn_Ecomercial;
        private Button btn_doispontoscima;
        private Button btn_Porcetagem;
        private Button btn_sifrao;
        private Button btn_hastag;
        private Button btn_Arroba;
        private Button btn_esclamacao;
        private Button btn_Aspas;
        private Label Lbl_Titulo;
        private TextBox Txb_Feedback;
        private Button Btn_irFormularios;
        private Label label4;
        private TextBox txb_Sobrenome;
        private Label label3;
        private Label lbl_Senha;
        private Label lbl_Nome;
        private TextBox txb_Idade;
        private TextBox txb_Nome;
        private Modulos.DesinButtons Btn_EnviarFeedBack;
        private Modulos.DesinButtons Btn_Home;
        private Modulos.DesinButtons Btn_Formulario;
        private PictureBox pictureBox1;
    }
}